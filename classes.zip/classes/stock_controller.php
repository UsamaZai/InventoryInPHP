<?php

	/**
	 * 
	 */
	class Stock 
	{
		
		function Add_Stock($name,$price,$qty)
		{
			if($name != null)
			{
				echo "Your record is insert";
			}
		}
		function Update_Stock($id)
		{
			if($id != null)
			{
				echo "Your record is insert";
			}
		}
	}

?>